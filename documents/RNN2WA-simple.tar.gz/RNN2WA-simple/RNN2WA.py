#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Sep 27 13:49:45 2019

@author: Remi Eyraud
"""

from os import listdir
from os.path import isfile, join
import sys 

import pickle

import splearn as sp

import models

import numpy as np
from numpy.linalg import svd, pinv

import torch
import torch.nn.functional as torch_funcs

def show(verbose, news):
    if verbose > 0:
        print(news)
        
def load_rnn(rnn_path, device):
    """ load a pytorch RNN from the path to a folder with 2 files: a digest whose name is "d" and the one of weights
    :param rnn_path: path to the folder
    :param device: 'cpu' or 'cuda' depending of your computer architecture
    :example: load_rnn("./my_rnn/", 'cpu')
    """
    onlyfiles = [f for f in listdir(rnn_path) if isfile(join(rnn_path, f))]
    for f in onlyfiles:
        if f != "d":
            weights = rnn_path + f
    digest = rnn_path + "d"
    with open(digest, "r") as dig:
        modelname = dig.readline()
        (nalpha, hidn_size) = tuple([int(s) for s in dig.readline().split()])
        rnn = models.LangMod(modelname, nalpha, hidn_size)

    if device!='cpu': rnn.load_state_dict(torch.load(weights))
    else: rnn.load_state_dict(torch.load(weights, map_location=device))
    rnn.to(device)
    return rnn

def gen_one_with_rnn(rnn, device):
    """Use the RNN to generate one word"""
    gen_word = []
    x = torch.tensor([[rnn.nalpha + 1]], dtype=torch.int64, device=device)
    hidden = torch.zeros((rnn.num_layers, 1, rnn.hidn_size), device=device)
    max_length = 100
    for i in range(max_length):
        y_scores, hidden = rnn(x, hidden)
        dist = torch_funcs.softmax((y_scores[0, 0, :-1]), dim=-1)
        selected = torch.multinomial(dist, 1).item()
        if selected == 0:
            break
        gen_word.append(selected - 1)
        x[0, 0] = selected
    return gen_word, selected

def add_all_prefixes(prefixes_set, word):
    """ add all prefixes of a word to an existing set of prefixes
    """
    for i in range(len(word)):
        prefixes_set.add(tuple(word[:i]))
def add_all_suffixes(suffixes_set, word):
    """ add all suffixes of a word to an existing set of prefixes
    """
    for i in range(len(word)):
        suffixes_set.add(tuple(word[i:]))
        
def generate_basis(rnn, nb_prefixes, nbL, device, verbose):
    
    """
    use the RNN to compute a set of prefixes and a set of suffixes
    :param rnn: a rnn in pytorch
    :param nb_prefixes: the number of prefixes and suffixes needed
    :param nbL: the size of the alphabet, i.e. the number of different symbols
    :param device: 'cup' or 'cuda'
    
    :return: a triplet (prefixes, suffixes, all_combination) where 
             all_combinaisons include all needed words (made by one of the prefixes,
             one of the suffixes, with or without a letter betwween them
    """
    show(verbose, "Creating Basis")
    words = set()
    prefixes = set()
    suffixes = set()
    suffixes.add(())

    with torch.no_grad():
        rnn.eval()

        while (len(prefixes) < nb_prefixes or len(suffixes) < nb_prefixes):
            gen_word, selected = gen_one_with_rnn(rnn, device)
            gen_word = tuple(gen_word)
            if selected == 0:
                if gen_word not in words:
                    words.add(gen_word)
                    if len(prefixes) < nb_prefixes:
                        add_all_prefixes(prefixes, list(gen_word))
                    if len(suffixes) < nb_prefixes:
                        add_all_suffixes(suffixes, list(gen_word))
                        
    # it's better to sort for the Hankel construction
    rows = sorted(list(prefixes))
    columns = sorted(list(suffixes))
    
    # need to create the set of all the words this basis implies to ask the RNN
    letters = [[]] + [[i] for i in range(nbL)]
    all_combinaisons = set()
    for letter in letters:
            for prefix in rows:
                for suffix in columns:
                    all_combinaisons.add(tuple(list(prefix) + letter + list(suffix)))
    return rows, columns, list(all_combinaisons)

def probas_all_prefixes(rnn, words, device, bsize=512):
    """Returns a dict containing next symbol conditional probas after every prefix of every word given, using an rnn model"""
    predictions = rnn.probas_tables_numpy(words, bsize, device=device)
    print("    probas_tables_numpy: Done")
    preds_dict = dict()
    for i, w in enumerate(words):
        for k in range(len(w)+1):	
            preds_dict[tuple(w[:k])] = predictions[i,k]
    return preds_dict

def compute_probas(rnn, all_combinaisons, nbL, device, verbose):
    """ return a dictionarywith all words as keys and corresponding RNN proba as values"""
    prefixes_dict = probas_all_prefixes(rnn, all_combinaisons, device=device)
    show(verbose, "    Done proba all prefixes")
    probas = dict()

    for word in all_combinaisons:
        word = list(word)
        indices = [x + 1 for x in word]
        indices.append(0)
        acc = 1
        for k in range(len(indices)):
            pref = tuple(word[:k])
            proba = prefixes_dict[pref][indices[k]]
            acc *= proba
        probas[tuple(word)] = acc

    return probas

def create_hankels(rnn, prefixes, suffixes, all_combinaisons, device, nbL, verbose):
    """
    Redefinition of hankels(): return the list of matrices needed for extracting WA
    :param rnn: a RNN in pytorch
    :param prefixes: the list of prefixes (for rows)
    :param suffixes: the list of suffixes (for columns)
    :param all_combinaisons: a list of all the words whose proba have to be rasked to the RNN
    :param device: 'cpu' or 'cuda'
    :param nbL: the number of letters of the problem
    :param verbose: whether something needs to be printed
    
    :return: a list of matrices lhankels. lhankels[0] is the Hankel matrice while
             lhankel[i] is H_{i-1}: lhankel[i][prefix][suffix]=p(prefix.(i-1).suffix)
    """
    show(verbose,"Creating Hankels")
    words_probas = compute_probas(rnn, all_combinaisons, nbL, device, verbose)
    show(verbose,"    Done computing probas")
    lhankels = [np.zeros((len(prefixes), len(suffixes))) for _ in range(nbL + 1)]
    # epsilon and letters matrices:
    letters = [[]] + [[i] for i in range(nbL)]
    for letter in range(len(letters)):
        for l in range(len(prefixes)):
            for c in range(len(suffixes)):
                p = words_probas[tuple(list(prefixes[l]) + letters[letter] + list(suffixes[c]))]
                lhankels[letter][l][c] = p
    return lhankels
    
def do_svd(hankels, verbose):
    show(verbose, "Doing SVD")
    hankel = hankels[0]
    [u, s, v] = svd(hankel)
    return [u, s, v]

def compute_scores(test_set, rnn, wa):
    print("to be done")

def extract_WA(rnn_path, rank,  nbL, nb_prefixes=0, pickle_hankel=None, pickle_svd=None, device='cpu', problem=None, verbose=0):
    """
        Extract a WA of given rank from a RNN
        
        :param rnn: path to a folder with 2 files (the Pytorch digest and parameter of the already learned RNN)
        :param rank: the rank of the WA to be extracted
        :param nbL: the number of different symbols (letters)
        :param nb_prefixes: number of prefixes (and suffiexs) for the basis (not needed if hankel and SVD already computed)
        :param pickle_hankel: path to the pickel of an already computed Hankel matrix
        :param pickel_svd: path to the pickel of an already computed SVD of the Hankel matrix
        :param device: whether a 'cpu' or gpu ('cuda') should be used for the RNN
        :param problem: the name of the problem for the pickles
        :param verbose: greater than 0 to allow prints
        
        :results: return the distiled weighted automata
        :example:   
    """
    if pickle_svd == None:
        if pickle_hankel == None:
            rnn= load_rnn(rnn_path, device)
            prefixes, suffixes, all_combinaisons = generate_basis(rnn, nb_prefixes, nbL, device, verbose)
            hankels = create_hankels(rnn, prefixes, suffixes, all_combinaisons, device, nbL, verbose)
            svd = do_svd(hankels, verbose)
            pickle.dump(hankels, open("pickles/"+problem+".hankels", "wb"))
            pickle.dump(svd, open("pickles/"+problem+".svd", "wb"))
        else:
            hankels = pickle.load(open(pickle_hankel,"rb"))
            svd = do_svd(hankels, verbose)
            pickle.dump(svd, open("pickles/"+problem+".svd", "wb"))
    else:
        if pickle_hankel == None:
            print("WARNING: SVD but no Hankel given. Implies redo both")
            rnn= load_rnn(rnn_path, device)
            prefixes, suffixes, all_combinaisons = generate_basis(rnn, nb_prefixes, nbL, device, verbose)
            hankels = create_hankels(rnn, prefixes, suffixes, all_combinaisons, device, nbL, verbose)
            svd = do_svd(hankels, verbose)
            pickle.dump(hankels, open("pickles/"+problem+".hankels", "wb"))
            pickle.dump(svd, open("pickles/"+problem+".svd", "wb"))
        else:
            hankels = pickle.load(open(pickle_hankel,"rb"))
            svd = pickle.load(open(pickle_svd, "rb"))
    show(verbose, "Done with Hankel and SVD")
    
    # Computing rank factoristaion from SVD
    hankel = hankels[0]
    [u, s, v] = svd
    u = u[:, :rank]
    v = v[:rank, :]
    ds = np.diag(s[:rank])
    
    #Computing WA elements
    pis = pinv(v)
    del v
    pip = pinv(np.dot(u, ds))
    del u, ds
    init = np.dot(hankel[0, :], pis)
    term = np.dot(pip, hankel[:, 0])
    transitions = []
    for x in range(nbL):
        hankel = hankels[x+1]
        transitions.append(np.dot(pip, np.dot(hankel, pis)))
    
    A = sp.Automaton(nbL=nbL, nbS=rank, initial=init, final=term, transitions=transitions, type="classic")
    return A

def main():
    if len(sys.argv) == 6:
        rnn_path = sys.argv[1]
        rank = int(sys.argv[2])
        nbL = int(sys.argv[3])
        nb_prefixes = int(sys.argv[4])
        problem = sys.argv[5]
        WA = extract_WA(rnn_path, rank,  nbL, nb_prefixes, device='cpu', problem=problem, verbose=1)
    elif len(sys.argv) == 7:
        rnn_path = sys.argv[1]
        rank = int(sys.argv[2])
        nbL = int(sys.argv[3])        
        nb_prefixes = int(sys.argv[4])
        pickle_hankel = sys.argv[5]
        pickle_svd = sys.argv[6]
        WA = extract_WA(rnn_path, rank,  nbL, nb_prefixes, pickle_hankel, pickle_svd, device='cpu', verbose=2)
    else:
        print("USAGE: python -u RNN2WA.py rnn_path rank nbL nb_prefixes problem")
        print("OR")
        print("USAGE: python -u RNN2WA.py rnn_path rank nbL nb_prefixes pickle_hankel pickle_svd")
        exit()
    file_dot = "1.SPiCe.rank_5.dot"
    dot = WA.get_dot(threshold=0.2, title=file_dot)
    from graphviz import Source
    src = Source(dot)
    src.render(file_dot + '.gv', view=True)

        
if __name__ == "__main__":
    main()

#python -u RNN2WA.py example-RNN-SPiCe1/ 5 20 50 SPiCe1-50x50
#python -u RNN2WA.py example-RNN-SPiCe1/ 5 20 50 pickles/SPiCe1-50x50.hankels pickles/SPiCe1-50x50.svd
